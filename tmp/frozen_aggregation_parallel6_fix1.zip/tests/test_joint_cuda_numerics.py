"""CPU regression checks for CUDA policy and the unchanged parallel acceptance gate."""
import os
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import patch

import torch

from scripts import run_cliplora_joint_aggregation as single
from scripts import run_cliplora_frozen_aggregation as suite
from scripts.run_ab_validation import write_json
from tools.client_aggregation.numerics import (DETERMINISTIC, prepare_environment,
    apply_policy, verify_active, verify_record, policy_for)
from tools.client_aggregation.parallel import LoRAClientPool, compare_states, compare_clients, comparison_passed
from tools.client_aggregation.protocol import load_json, client_execution_config


class TestCudaNumerics(unittest.TestCase):
    def test_registered_policy_defaults_and_propagation(self):
        self.assertEqual(policy_for({}), 'legacy')  # archived plans stay auditable
        self.assertNotIn('cuda_numerics', client_execution_config({'settings': {'client_concurrency': 6}}))
        self.assertEqual(single.parse_args([]).cuda_policy, 'legacy')
        for rule in ('fedavg', 'tailrw16'):
            args = single.parse_args(['--aggregation-rule', rule])
            self.assertEqual(args.cuda_policy, 'deterministic')
            for cmd in single.server_commands(args, 'frozen'):
                self.assertEqual(cmd[cmd.index('--cuda-policy')+1], 'deterministic')
        args = suite.parse_args([])
        for rule in suite.METHODS:
            for cmd in suite.commands(args, rule):
                self.assertEqual(cmd[cmd.index('--cuda-policy')+1], 'deterministic')

    def test_environment_and_backend_policy_restore_benchmark_override(self):
        before = (torch.are_deterministic_algorithms_enabled(), torch.is_deterministic_algorithms_warn_only_enabled(),
                  torch.backends.cudnn.benchmark, torch.backends.cudnn.deterministic)
        precision = (torch.backends.cuda.matmul.allow_tf32, torch.backends.cudnn.allow_tf32)
        try:
            with patch.dict(os.environ, {'CUBLAS_WORKSPACE_CONFIG': ':16:8'}):
                prepare_environment('deterministic')
                self.assertEqual(os.environ['CUBLAS_WORKSPACE_CONFIG'], ':4096:8')
                apply_policy('deterministic')
                verify_active('deterministic')
                torch.backends.cudnn.benchmark = True  # federated_main's old setup
                with self.assertRaisesRegex(ValueError, 'cudnn_benchmark'):
                    verify_active('deterministic')
                apply_policy('deterministic')  # runtime reapplies before training
                verify_active('deterministic')
                self.assertEqual(precision, (torch.backends.cuda.matmul.allow_tf32, torch.backends.cudnn.allow_tf32))
            with patch.dict(os.environ, {'CUBLAS_WORKSPACE_CONFIG': ':bad:'}):
                with self.assertRaisesRegex(ValueError, 'before CUDA'):
                    apply_policy('deterministic')
        finally:
            torch.use_deterministic_algorithms(before[0], warn_only=before[1])
            torch.backends.cudnn.benchmark, torch.backends.cudnn.deterministic = before[2:]

    def test_policy_is_frozen_in_plan_and_runtime_record(self):
        with tempfile.TemporaryDirectory() as temp:
            args = single.parse_args(['--aggregation-rule', 'tailrw16', '--output-root', temp])
            plan = single.register(args)
            self.assertEqual(plan['settings']['cuda_policy'], 'deterministic')
            self.assertEqual(client_execution_config(single.make_job(plan, 'frozen'))['cuda_numerics'], DETERMINISTIC)
            args.cuda_policy = 'legacy'
            with self.assertRaisesRegex(ValueError, 'changed'): single.register(args)
        record = {k:v for k,v in DETERMINISTIC.items() if k not in ('policy', 'tf32')}
        verify_record(record)
        record['warn_only'] = True
        with self.assertRaisesRegex(ValueError, 'warn_only'): verify_record(record)

    def test_reported_failures_still_fail_original_tolerance(self):
        reference = {'example_lora_B': torch.zeros(2)}
        for err in (3.69315966963768e-6, 7.840804755687714e-6):
            result = compare_states(reference, {'example_lora_B': torch.tensor([err, 0.])})
            self.assertFalse(result['close'])
            self.assertEqual((result['atol'], result['rtol']), (1e-6, 1e-5))
            self.assertEqual(result['worst_parameter'], 'example_lora_B')
        self.assertTrue(compare_states(reference, {'example_lora_B': torch.tensor([5.256151780486107e-7, 0.])})['close'])

    def test_equal_parameters_cannot_hide_budget_or_batch_changes(self):
        first = {0: ({'B': torch.ones(1)}, {'optimizer_steps': 3}, {'slot': 0, 'batch_plan_sha256': 'same'})}
        second = {0: ({'B': torch.ones(1)}, {'optimizer_steps': 4}, {'slot': 1, 'batch_plan_sha256': 'same'})}
        self.assertFalse(comparison_passed(compare_clients(first, second, [0])[0]))
        second[0][1]['optimizer_steps'] = 3
        second[0][2]['batch_plan_sha256'] = 'changed'
        self.assertFalse(comparison_passed(compare_clients(first, second, [0])[0]))

    def test_pilot_rejects_serial_instability_and_names_failing_client(self):
        with tempfile.TemporaryDirectory() as temp, patch('builtins.print'):
            model = torch.nn.Linear(1, 1, bias=False)
            pool = object.__new__(LoRAClientPool)
            pool.slots = 6; pool.keys = ['weight']
            pool.runtime = SimpleNamespace(job={}, root=Path(temp), trainer=SimpleNamespace(model=model))
            state = {k:v.clone() for k,v in model.state_dict().items()}
            call = 0
            def run(start, clients, plans, factor, slots=None):
                nonlocal call
                call += 1
                results = {c: ({'B': torch.tensor([0.])}, {'optimizer_steps': 3},
                              {'slot': 0, 'batch_plan_sha256': str(c)}) for c in clients}
                if call == 3:  # warmup, serial, then serial repeat
                    results[1][0]['B'] += 7e-6
                return results, {'seconds': 1., 'slots': slots or 6, 'clients': len(clients)}
            pool.run = run
            plans = {c:[[[0]]] for c in range(8)}
            with self.assertRaisesRegex(ValueError, 'serial_repeat client=1'):
                pool.benchmark(state, list(range(8)), plans, 'B')
            report = load_json(Path(temp)/'parallel_benchmark/factor_B.json')
            self.assertFalse(report['passed'])
            self.assertTrue(all(r['close'] for r in report['comparisons']))
            self.assertEqual(report['pilot_version'], 2)
            self.assertEqual(len(report['serial_repeat_comparisons']), 8)


if __name__ == '__main__':
    unittest.main()
